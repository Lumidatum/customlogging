# Type (CouchDB, sqllite3, plain text, JSON text)
# Local or S3 for files
# Credentials for non-local

def fromFile(path_to_config_file):
    pass

def fromEnv(*environment_variables):
    pass
